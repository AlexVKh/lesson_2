number_of_tasks = 12
hours = 1.5
name_of_course = 'Python'
one_task_time = number_of_tasks / hours
print('Курс:',name_of_course, ', всего задач:', number_of_tasks, ', затрачено часов:', hours, ', среднее время выполнения:', one_task_time, 'часа')
